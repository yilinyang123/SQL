<!-- <?php

if (isset($_POST['submit'])) {

    require_once("conn.php");

    $hospital = $_POST['hospital'];

    $query = "SELECT prf_rate FROM group_score WHERE org_nm = :hospital";

try
    {
      $prepared_stmt = $dbo->prepare($query);
      $prepared_stmt->bindValue(':hospital', $hospital, PDO::PARAM_STR);
      $prepared_stmt->execute();
      $result = $prepared_stmt->fetchAll();

    }
    catch (PDOException $ex)
    { // Error in database processing.
      echo $sql . "<br>" . $error->getMessage(); // HTTP 500 - Internal Server Error
    }
}
?> -->

<style>
label {
  display: block;
  margin: 5px 0;
}

table {
  border-collapse: collapse;
  border-spacing: 0;
}

td, th {
  padding: 5px 30px 5px 30px;
  border-bottom: 1px solid #aaa;
}

</style>



<?php
$profpic = "images/bg-img-01.jpg";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <style type="text/css">

    body {
    background-image: url('<?php echo $profpic;?>');
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Colrolib Templates">
    <meta name="author" content="Colrolib">
    <meta name="keywords" content="Colrolib Templates">

    <!-- Title Page-->
    <title>Au Form Wizard</title>

    <!-- Icons font CSS-->
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/datepicker/daterangepicker.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/main.css" rel="stylesheet" media="all">
</head>

<body>
    <div class="page-wrapper bg-img-1 p-t-165 p-b-100">
        <div class="wrapper wrapper--w720">
            <div class="card card-3">
                <div class="card-body">
                    <ul class="tab-list">
                        <li class="tab-list__item active">
                            <a class="tab-list__link" href="#tab1" data-toggle="tab">hospitals</a>
                        </li>
                        <li class="tab-list__item">
                            <a class="tab-list__link" href="#tab2" data-toggle="tab">doctors</a>
                        </li>
                        <li class="tab-list__item">
                            <a class="tab-list__link" href="#tab3" data-toggle="tab">condition</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab1">
                            <form method="POST" action="">
                                <div class="input-group">
                                    <label class="label">Going to</label>
                                    <input type="text" name="hospital" id="hospital" value="<?php echo isset($_POST['hospital']) ? $_POST['hospital'] : '' ?>">
                                    <i class="zmdi zmdi-pin input-group-symbol"></i>
                                </div>
                                <!-- <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">check-in</label>
                                            <input class="input--style-1" type="text" name="check-in" placeholder="mm/dd/yyyy" id="input-start">
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">check-out</label>
                                            <input class="input--style-1" type="text" name="check-out" placeholder="mm/dd/yyyy" id="input-end">
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group">
                                    <label class="label">travellers</label>
                                    <i class="zmdi zmdi-account-add input-group-symbol"></i>
                                    <div class="input-group-icon" id="js-select-special">
                                        <input class="input--style-1" type="text" name="traveller" value="1 Adult, 0 Children, 1 Room" disabled="disabled" id="info">
                                        <i class="zmdi zmdi-chevron-down input-icon"></i>
                                    </div>
                                    <div class="dropdown-select">
                                        <ul class="list-room">
                                            <li class="list-room__item">
                                                <span class="list-room__name">Room 1</span>
                                                <ul class="list-person">
                                                    <li class="list-person__item">
                                                        <span class="name">Adults</span>
                                                        <div class="quantity quantity1">
                                                            <span class="minus">-</span>
                                                            <input class="inputQty" type="number" min="0" value="1">
                                                            <span class="plus">+</span>
                                                        </div>
                                                    </li>
                                                    <li class="list-person__item">
                                                        <span class="name">Children</span>
                                                        <div class="quantity quantity2">
                                                            <span class="minus">-</span>
                                                            <input class="inputQty" type="number" min="0" value="0">
                                                            <span class="plus">+</span>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>
                                        <div class="list-room__footer">
                                            <a href="#" id="btn-add-room">Add room</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="checkbox-row">
                                    <label class="checkbox-container m-r-45">Add a flight
                                        <input type="checkbox" checked="checked" name="add-flight">
                                        <span class="checkmark"></span>
                                    </label>
                                    <label class="checkbox-container">Add a car
                                        <input type="checkbox" name="add-car">
                                        <span class="checkmark"></span>
                                    </label>
                                </div> -->
                                <button class="btn-submit" type="submit" name="submit" >search</button>
                                <!-- <input type="submit" name="submit" value="Submit"> -->
                                
                                <span class='btn-submit' align=center><?php include "form.php"; ?></span>
                            </form>
                        </div>
                        <div class="tab-pane" id="tab2">
                            <form method="POST" action="#">
                                <div class="input-group">
                                    <label class="label">location:</label>
                                    <input class="input--style-1" type="text" name="location" placeholder="Destination, hotel name" required="required">
                                    <i class="zmdi zmdi-pin input-group-symbol"></i>
                                </div>
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">driver age:</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <div class="rs-select2 js-select-simple select--no-search">
                                                <select name="driver-age">
                                                    <option>23</option>
                                                    <option>24</option>
                                                    <option selected="selected">25</option>
                                                    <option>26</option>
                                                </select>
                                                <div class="select-dropdown"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">car group:</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <div class="rs-select2 js-select-simple select--no-search">
                                                <select name="car-group">
                                                    <option selected="selected">Group S-car</option>
                                                    <option>Group 1</option>
                                                    <option>Group 2</option>
                                                    <option>Group 3</option>
                                                </select>
                                                <div class="select-dropdown"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">pick up:</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <input class="input--style-1 js-single-datepicker" type="text" name="pickup" placeholder="mm/dd/yyyy" data-drop="1">
                                            <div class="dropdown-datepicker" id="dropdown-datepicker1"></div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">time:</label>
                                            <i class="zmdi zmdi-time input-group-symbol"></i>
                                            <div class="rs-select2 js-select-simple select--no-search">
                                                <select name="time-pickup">
                                                    <option selected="selected">10:00 AM</option>
                                                    <option>5:00 AM</option>
                                                    <option>6:00 AM</option>
                                                    <option>7:00 AM</option>
                                                </select>
                                                <div class="select-dropdown"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">drop off:</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <input class="input--style-1 js-single-datepicker" type="text" name="dropoff" placeholder="mm/dd/yyyy" data-drop="2">
                                            <div class="dropdown-datepicker" id="dropdown-datepicker2"></div>
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">time:</label>
                                            <i class="zmdi zmdi-time input-group-symbol"></i>
                                            <div class="rs-select2 js-select-simple select--no-search">
                                                <select name="time-dropoff">
                                                    <option selected="selected">10:00 AM</option>
                                                    <option>5:00 AM</option>
                                                    <option>6:00 AM</option>
                                                    <option>7:00 AM</option>
                                                </select>
                                                <div class="select-dropdown"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn-submit m-t-15" type="submit">search</button>
                            </form>
                        </div>
                        <div class="tab-pane" id="tab3">
                            <form method="POST" action="#">
                                <div class="input-group">
                                    <label class="label">origin</label>
                                    <i class="zmdi zmdi-pin input-group-symbol"></i>
                                    <input class="input--style-1" type="text" name="origin" placeholder="City or airport" required="required">
                                </div>
                                <div class="input-group">
                                    <label class="label">destination:</label>
                                    <i class="zmdi zmdi-pin input-group-symbol"></i>
                                    <input class="input--style-1" type="text" name="destination" placeholder="City or airport" required="required">
                                </div>
                                <div class="row row-space">
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">Departing</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <input class="input--style-1" type="text" name="check-in" placeholder="mm/dd/yyyy" id="input-start-2">
                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <div class="input-group">
                                            <label class="label">returning</label>
                                            <i class="zmdi zmdi-calendar-alt input-group-symbol"></i>
                                            <input class="input--style-1" type="text" name="check-out" placeholder="mm/dd/yyyy" id="input-end-2">
                                        </div>
                                    </div>
                                </div>
                                <div class="radio-row">
                                    <label class="radio-container m-r-45">First Class
                                        <input type="radio" name="class">
                                        <span class="radio-checkmark"></span>
                                    </label>
                                    <label class="radio-container m-r-45">Business
                                        <input type="radio" name="class">
                                        <span class="radio-checkmark"></span>
                                    </label>
                                    <label class="radio-container">Economy
                                        <input type="radio" checked="checked" name="class">
                                        <span class="radio-checkmark"></span>
                                    </label>
                                </div>
                                <button class="btn-submit" type="submit">search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <!-- Vendor JS-->
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/jquery-validate/jquery.validate.min.js"></script>
    <script src="vendor/bootstrap-wizard/bootstrap.min.js"></script>
    <script src="vendor/bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
    <script src="vendor/datepicker/moment.min.js"></script>
    <script src="vendor/datepicker/daterangepicker.js"></script>

    <!-- Main JS-->
    <script src="js/global.js"></script>

</body><!-- This templates was made by Colorlib (https://colorlib.com) -->

</html>
<!-- end document-->