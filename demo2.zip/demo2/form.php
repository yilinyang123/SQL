<?php

if (isset($_POST['submit'])) {

    require_once("conn.php");

    $hospital = $_POST['hospital'];

    $query = "SELECT prf_rate FROM group_score WHERE org_nm = :hospital";

try
    {
      $prepared_stmt = $dbo->prepare($query);
      $prepared_stmt->bindValue(':hospital', $hospital, PDO::PARAM_STR);
      $prepared_stmt->execute();
      $result = $prepared_stmt->fetchAll();

    }
    catch (PDOException $ex)
    { // Error in database processing.
      echo $sql . "<br>" . $error->getMessage(); // HTTP 500 - Internal Server Error
    }
}
?>

<div class="tab-pane active">
<?php
if (isset($_POST['submit'])) {
  if ($result && $prepared_stmt->rowCount() > 0) { ?>
    
    <h2>Results</h2>

    <table>
      <thead>
    <tr>
      <th>Performance Rate</th>
    </tr>
      </thead>
      <tbody>
  
<?php foreach ($result as $row) { ?>
      
      <tr>
    <td><?php echo $row["prf_rate"]; ?></td>
      </tr>
<?php } ?>
      </tbody>
  </table>
  
<?php } else { ?>
    > No results found for <?php echo $_POST['hospital']; ?>.
  <?php }
} ?>
</div>